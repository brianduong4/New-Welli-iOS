//
//  Welli_iOSApp.swift
//  Welli-iOS Watch App
//
//  Created by Raul Cheng on 4/4/23.
//
//MARK: THIS IS THE MAIN CONTROL POINT OF THE APP UPON LAUNCH


import SwiftUI
import WatchKit
import UserNotifications
import WatchConnectivity
import HealthKit
import UIKit





@main


struct Welli_iOS_Watch_AppApp: App {
    @Environment(\.scenePhase) private var scenePhase
    @WKApplicationDelegateAdaptor(ExtensionDelegate.self) var extensionDelegate
    
    @StateObject var environmentObject = WriteViewModel()

    
    init() {
        HeartRateMonitor.shared.startMonitoringHeartRate()
        
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) {
            success, error in
            if success {
                print("All set!")
            } else if let error = error {
                print(error.localizedDescription)
            }
        }
    }
    
    
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(environmentObject)
                .onAppear {
                if WCSession.isSupported() {
                    WCSession.default.activate()
                }
            }
            
        }
        
    }
}

