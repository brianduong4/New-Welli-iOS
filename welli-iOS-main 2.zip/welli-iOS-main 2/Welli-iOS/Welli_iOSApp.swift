//
//  Welli_iOSApp.swift
//  Welli-iOS
//
//  Created by Raul Cheng on 4/4/23.
//

import UIKit
import SwiftUI
import Firebase
import FirebaseDatabase
import HealthKit
import BackgroundTasks
import UserNotifications


@main
struct Welli_iOSApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    
    init() {
        FirebaseApp.configure()
    }
    
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

